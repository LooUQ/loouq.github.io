// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
 
#ifdef ARDUINO
  #include "AzureIoTHub.h"
#else
  #include "azure_c_shared_utility/threadapi.h"
  #include "azure_c_shared_utility/platform.h"
  #include "serializer.h"
  #include "iothub_client_ll.h"
  #include "iothubtransporthttp.h"
#endif
#include "sdk/schemaserializer.h"

#include <iotQi-globals.h>
#include <iotQi-utility.h>
#include "user-model.h"

/* ------------------------------------------------------------------------------------------------------------------------------------------
 *  Add any required headers for project specific functionality.  These headers are likely to be required in the UserModel.c file as well.
------------------------------------------------------------------------------------------------------------------------------------------ */

#include "bme280.h"
#include "oled-display.h"

/* ------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------ */

/* ==========================================================================================================================================
 *  Model Type            Description
 *  -------------------   ---------------------------------------------
 *  double                double precision floating point number
 *  int                   32 bit integer
 *  float                 single precision floating point number
 *  long                  long integer
 *  int8_t                8 bit integer
 *  int16_t               16 bit integer
 *  int32_t               32 bit integer
 *  int64_t               64 bit integer
 *  bool                  boolean
 *  ascii_char_ptr        ASCII string
 *  EDM_DATE_TIME_OFFSET  date time offset
 *  EDM_GUID              GUID
 *  EDM_BINARY            binary
 *  DECLARE_STRUCT        complex data type

https://docs.microsoft.com/en-us/azure/iot-hub/iot-hub-device-sdk-c-serializer
========================================================================================================================================== */

BEGIN_NAMESPACE(UserNamespace);

DECLARE_STRUCT(_Telemetry,
    float, Temperature,
    float, Humidity,
    float, BarPressure,
    int, SampleId
);

DECLARE_STRUCT(_DeviceInfo,
    float, VBat,
    long, FreeRam,
    int, Rssi
);

DECLARE_MODEL(UserModel,
    WITH_DATA(_Telemetry, Telemetry),
    WITH_DATA(_DeviceInfo, DeviceInfo),
    WITH_DATA(float, Temperature),
    WITH_DATA(float, Humidity),
    WITH_DATA(float, BarPressure),
    WITH_DATA(int, SampleId),

    WITH_ACTION(SetTemperature, int, temperature),
    WITH_ACTION(SetHumidity, int, humidity)
);

END_NAMESPACE(UserNamespace);

UserModel* userContext;

/* Add any variables that need to persistent across samples  */
int sampleId = 0;


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

EXECUTE_COMMAND_RESULT SetTemperature(UserModel* userContext, int temperature)
{
    (void)printf("Received temperature %d\r\n", temperature);
    userContext->Telemetry.Temperature = temperature;
    return EXECUTE_COMMAND_SUCCESS;
}

EXECUTE_COMMAND_RESULT SetHumidity(UserModel* userContext, int humidity)
{
    (void)printf("Received humidity %d\r\n", humidity);
    userContext->Telemetry.Humidity = humidity;
    return EXECUTE_COMMAND_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


IOTOS_RESULT GetTelemetrySample(unsigned char** buffer, size_t* bufferSize, char* eventName, char* displayValue)
{
  float sampleTemp;
  float samplePress;
  float sampleHumid;

  // user defined sample
  (void)printf("\r\n*** Collecting telemetry sample ***\r\n");
  readBmeValues(&sampleTemp, &samplePress, &sampleHumid);
  userContext->Telemetry.Temperature = sampleTemp;
  userContext->Telemetry.BarPressure = samplePress;
  userContext->Telemetry.Humidity = sampleHumid;
  userContext->Telemetry.SampleId = ++sampleId;
  userContext->DeviceInfo.VBat = GetVbat();
  userContext->DeviceInfo.FreeRam = GetFreeRam();
  userContext->DeviceInfo.Rssi = GetRssi();

  /* The following 2 lines copy telemetry event information into the event message properties going out to the iotQi cloud hub 
   *  These 2 properties will be found in your event table data as columns
   *  
   *  Note: snprintf has floating support
   *  Max Lengths: 80 characters for displayValue, 80 characters for eventName
   */
  snprintf(displayValue, DISPLAYVALUE_SIZE, "Temperature=%.2f", sampleTemp);
  strncpy(eventName, "Temperature_Humidity_BarPressure", EVENTNAME_SIZE);
  
  //(void)printf("Serializing sensor value: %s (%d)\r\n", displayValue, sampleId);
  oledDisplay_showWifiStatus();
  oledDisplay_refreshIcons();

  if (SERIALIZE(buffer, bufferSize, userContext->DeviceInfo, userContext->Telemetry) != CODEFIRST_OK)
  {
    (void)printf("Error serializing telemetry sample");
    return IOTOS_ERROR;
  }
  return IOTOS_OK;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


IOTOS_RESULT User_ModelInit()
{
  userContext = CREATE_MODEL_INSTANCE(UserNamespace, UserModel);
  if (userContext == NULL)
  {
    (void)printf("Failed on to create user telemetry model.\r\n");
    return IOTOS_ERROR;
  }
  return IOTOS_OK;
}

void User_ModelDeinit()
{
  DESTROY_MODEL_INSTANCE(userContext);
}

IOTOS_RESULT User_GetCommands(STRING_HANDLE commandsMeta)
{
  if (SchemaSerializer_SerializeCommandMetadata(GET_MODEL_HANDLE(UserNamespace, UserModel), commandsMeta) != SCHEMA_SERIALIZER_OK)
  {
    return IOTOS_ERROR;
  }
  return IOTOS_OK;
}


EXECUTE_COMMAND_RESULT User_InvokeCommand(char* cmdBuffer)
{
  EXECUTE_COMMAND(userContext, cmdBuffer);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


extern char *sbrk(int i);

int GetFreeRam () {
  char stack_dummy = 0;
  return &stack_dummy - sbrk(0);
}
