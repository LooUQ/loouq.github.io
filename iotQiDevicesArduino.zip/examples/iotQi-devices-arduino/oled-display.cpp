// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "oled-display.h"
#include "settings.h"
#include "iotQi_FeatherOLED.h"
#include "iotQi_FeatherOLED_WiFi.h"

#include <WiFi101.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>


iotQi_FeatherOLED_WiFi display = iotQi_FeatherOLED_WiFi();


void oledDisplay_init(int vbatEnabled, int vbatPin)
{
    display.init(vbatEnabled, vbatPin);
}


void oledDisplay_writeLine(int lineNum, const char* lineText)
{
  display.writeLine(lineNum, lineText);
}

void oledDisplay_clearMsgArea(){
  display.writeLine(2, "");
  display.writeLine(3, "");
}

void oledDisplay_showWifiStatus()
{
  int wifiStatus = WiFi.status();
  int8_t rssi = WiFi.RSSI();
  
  display.setRSSIVisible(true);
  display.setRSSI(rssi);

  if (wifiStatus == WL_CONNECTED) {
    IPAddress ipAddress = WiFi.localIP();
    char* ssid[80];
    display.setConnected(true);
    display.setIPAddressVisible(true);
    display.setIPAddress(ipAddress);
    display.refreshIcons();
    //display.writeLine(2, "Connected:");
    //display.writeLine(3, WIFI_SSID);
  }
  else {
    display.writeLine(2, "WiFi:Not connected");
    display.writeLine(3, "");
  }
}

void oledDisplay_refreshIcons()
{
  display.refreshIcons();
}

