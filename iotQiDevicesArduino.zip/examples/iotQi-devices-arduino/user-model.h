// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __USER_MODEL_H
#define __USER_MODEL_H


#ifdef __cplusplus
extern "C" {
#endif

IOTOS_RESULT GetTelemetrySample(unsigned char** buffer, size_t* bufferSize, char* eventName, char* displayValue);

IOTOS_RESULT User_ModelInit();
void User_ModelDeinit();
IOTOS_RESULT User_GetCommands(STRING_HANDLE commandsMeta);
EXECUTE_COMMAND_RESULT User_InvokeCommand(char* cmdBuffer);

#ifdef __cplusplus
}
#endif

#endif      // #define __USER_MODEL_H

