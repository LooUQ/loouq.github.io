// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __OLED_DISPLAY_H_
#define __OLED_DISPLAY_H_


#ifdef __cplusplus
extern "C" {
#endif

  void oledDisplay_init(int vbatEnabled, int vbatPin);
  void oledDisplay_writeLine(int lineNum, const char* lineText);
  void oledDisplay_clearMsgArea();
  void oledDisplay_showWifiStatus();
  void oledDisplay_refreshIcons();

#ifdef __cplusplus
}
#endif

#endif    // #define __OLED_DISPLAY_H_

