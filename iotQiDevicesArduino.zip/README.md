== LooUQ IoTQi Library for Arduino ==

The LooUQ IoTQi library allows a device to connect to the LooUQ cloud. Device support includes: ESP8266,
Adafruit Feather M0, Arduino/Genuino MKR1000, Arduino Zero

For more inoformation about this library please visit:
https://support.loouq.com/hc/en-us

== Prerequisities ==

You should have the following libraries installed inorder to support IoTQi:
-	[Setup your IoT device with Setup] (https://setup.loouq.com/)
-	[Arduino IDE 1.8.1] (https://www.arduino.cc/en/Main/Software)
-	Install the following libraries via the Arduino IDE Library Manager
	{
		'Adafruit BME280 Library',
		'Adafruit GFX Library',
		'Adafruit IO Arduino',
		'Adafruit SSD1306',
		'Adafruit Unified Sensor',
		'AzureIoTHub',
		'AzureIoTProtocol_HTTP',
		'AzureIoTProtocol_MQTT',
		'AzureIoTUtility',
		'WiFi'
		'NTPClient',
		'RTCZero',
		'SAMD_AnalogCorrection',
		'SPI',
		'WiFi101',
		'Wire'
	}

== License ==

Copyright (c) 2016 LooUQ Incorporated. All rights reserved.
Copyright (c) Arduino. All rights reserved.
Licensed under the MIT license. See LICENSE file in the project root for full license information.