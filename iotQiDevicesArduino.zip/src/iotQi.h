// Copyright (c) Microsoft. All rights reserved.
// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __LOOUQ_IOTOS_H
#define __LOOUQ_IOTOS_H


#define IOTOS_RESULT_VALUES   \
    IOTOS_OK,                 \
    IOTOS_INVALID_ARG,        \
    IOTOS_ERROR

DEFINE_ENUM(IOTOS_RESULT, IOTOS_RESULT_VALUES)

#define IOTOS_COMMANDS_LIST "GetDeviceId,GetVersionInfo,GetNetworkInfo,GetCommandsInfo"


// Message Properties
extern const char* const IOTOS_VERSION;
extern const char* const HTTP_OK;

extern const char* const IotqiMsgProp_iotQiVersion;
extern const char* const IotqiMsgProp_MessageType;
extern const char* const IotqiMsgProp_EventClass;                       // command class, alert class, or telemetry series metric class
extern const char* const IotqiMsgProp_EventName;                         // user-defined name or title for the series
extern const char* const IotqiMsgProp_DisplayValue;

// iotQi Message Types
extern const char* const IotqiMsgType_Command;
extern const char* const IotqiMsgType_CommandResponse;
extern const char* const IotqiMsgType_Telemetry;
extern const char* const IotqiMsgType_Alert;

// iotQi Message Event Classes
extern const char* const IotqiEventClass_Iotqi;
extern const char* const IotqiEventClass_User;


#ifdef __cplusplus
extern "C" {
#endif

void iotQi_Run(const char* connectionString, unsigned int sampleInterval);

#ifdef __cplusplus
}
#endif


#endif //#define __LOOUQ_IOTOS_H
