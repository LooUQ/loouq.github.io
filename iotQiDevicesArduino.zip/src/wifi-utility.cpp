// Copyright (c) Microsoft. All rights reserved.
// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include <Arduino.h>
#include <WiFi101.h>

#include "wifi-utility.h"

///////////////////////////////////////////////////////////////////////////////////////////////////

int GetRssi()
{
    int8_t rssi = WiFi.RSSI();
    return rssi;
}

