// Copyright (c) Microsoft. All rights reserved.
// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __WIFI_UTILITY_H
#define __WIFI_UTILITY_H

#define UNITS_TYPE_METRIC        (0)
#define UNITS_TYPE_IMPERIAL      (1)


#ifdef __cplusplus
extern "C" {
#endif

int GetRssi();



#ifdef __cplusplus
}
#endif


#endif      // __WIFI_UTILITY_H
