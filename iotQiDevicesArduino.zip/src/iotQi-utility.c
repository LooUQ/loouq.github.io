// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include <stdlib.h>
#include <Arduino.h>

#ifdef ARDUINO
  #include "AzureIoTHub.h"
#else
  #include "azure_c_shared_utility/threadapi.h"
  #include "azure_c_shared_utility/platform.h"
  #include "serializer.h"
  #include "iothub_client_ll.h"
  #include "iothubtransporthttp.h"
#endif
#include "iotQi-globals.h"
#include "iotQi-utility.h"


// jsonAddName encapsulates existing json object\array inside a new structure with a name applied to the existing object\array
void jsonAddName(unsigned char** buffer, size_t* bufferSize, const char* nameToAdd)
{
    int nameSize = strlen(nameToAdd);
    char* newBuffer;
    newBuffer = (char*)calloc(*bufferSize + nameSize + 6 , sizeof(char));     // make space for {" ": }

    //printf("jsonAddName() newBufferSize=%d \r\n", *bufferSize + nameSize + 6);
    memcpy(newBuffer, "{\"", 2);
    memcpy(newBuffer + 2, nameToAdd, nameSize);
    memcpy(newBuffer + (2 + nameSize), "\":", 2);
    memcpy(newBuffer + (4 + nameSize ), *buffer, *bufferSize);
    memcpy(newBuffer + (4 + nameSize + *bufferSize), "}\0", 2);

    free(*buffer);
    *bufferSize = *bufferSize + nameSize + 6;
    *buffer = newBuffer;
}


// jsonInsert inserts a json object >> "string":value, << into an existing json structure, the inserted obj will be the 1st object
void jsonInsert(unsigned char** buffer, size_t* bufferSize, const char* objToInsert)
{
    int objSize = strlen(objToInsert);
    char* newBuffer;
    newBuffer = (char*)calloc(*bufferSize + objSize + 1, sizeof(char));       // make space for the ,

    memcpy(newBuffer, "{", 1);
    memcpy(newBuffer + 1, objToInsert, objSize);
    memcpy(newBuffer + (objSize + 1), ",", 1);
    memcpy(newBuffer + (2 + objSize), (*buffer) + 1, *bufferSize - 1);

    free(*buffer);
    *bufferSize = *bufferSize + objSize + 1;
    *buffer = newBuffer;
}


void IPAddressAsString(const char* buffer, uint32_t ipAddr)
{
    unsigned char bytes[4];
    bytes[3] = ipAddr & 0xFF;
    bytes[2] = (ipAddr >> 8) & 0xFF;
    bytes[1] = (ipAddr >> 16) & 0xFF;
    bytes[0] = (ipAddr >> 24) & 0xFF;  
    sprintf(buffer,"%d.%d.%d.%d", bytes[3], bytes[2], bytes[1], bytes[0]);
}


char* GetMessageProperty(IOTHUB_MESSAGE_HANDLE message, const char* const propName)
{
    MAP_HANDLE mapProperties = IoTHubMessage_Properties(message);
    if (mapProperties != NULL)
    {
        const char*const* keys;
        const char*const* values;
        size_t propCount = 0;
        if (Map_GetInternals(mapProperties, &keys, &values, &propCount) == MAP_OK)
        {
            if (propCount > 0)
            {
                //printf("Message Properties:\r\n");
                for (size_t i = 0; i < propCount; i++)
                {
                    //printf("\tKey: %s Value: %s\r\n", keys[i], values[i]);
                    if (strcmp(keys[i], propName) == 0)
                    {
                      return (char*)values[i];
                    }
                }
                //printf("\r\n");
            }
        }
    }
}


void SetGlobalDeviceIdFromConnectionString(const char* connectionString)
{
  char* idStart = strstr(connectionString, ";DeviceId=") + 10;
  char* idEnd = strstr(idStart, ";");
  int toCopy = idEnd - idStart;
  
  if(toCopy > 0 && toCopy < 40)
  {
    strncpy(deviceId, idStart, toCopy);
    deviceId[toCopy + 1] = "\0";
  }
  printf("DeviceId: %s\r\n", deviceId);
}

float GetVbat()
{
  float measuredvbat = 0.0;
  
  #ifdef ARDUINO_SAMD_FEATHER_M0
    #define VBAT_PIN                  A7
    // Read the analog in value:
    measuredvbat = analogRead(VBAT_PIN);
    measuredvbat = analogRead(VBAT_PIN);
    measuredvbat *= 2; // we divided by 2, so multiply back
    measuredvbat *= 3.3; // Multiply by 3.3V, our reference voltage
    measuredvbat /= 1024; // convert to voltage
  
  #elif defined(ESP8266)
  
  #elif defined(ARDUINO_SAMD_ZERO) || defined(ARDUINO_SAMD_MKR1000) 
  
  #endif

  //printf("GetVbat()  Vbat=%.2f\r\n",measuredvbat);
  return (measuredvbat);
}

