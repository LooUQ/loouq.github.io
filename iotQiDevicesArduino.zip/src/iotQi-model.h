// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __IOTOS_MODEL_H
#define __IOTOS_MODEL_H


#ifdef __cplusplus
extern "C" {
#endif

IOTOS_RESULT Iotqi_ModelInit();
void Iotqi_ModelDeinit();
IOTOS_RESULT Iotqi_GetCommands(STRING_HANDLE commandsMeta);
EXECUTE_COMMAND_RESULT Iotqi_InvokeCommand(char* cmdBuffer);

IOTOS_RESULT getDeviceMeta(unsigned char** buffer, size_t* bufferSize);


#ifdef __cplusplus
}
#endif

#endif    // #define __IOTOS_MODEL_H

