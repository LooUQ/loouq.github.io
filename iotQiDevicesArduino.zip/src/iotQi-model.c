// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
 
#ifdef ARDUINO
  #include "AzureIoTHub.h"
#else
  #include "azure_c_shared_utility/threadapi.h"
  #include "azure_c_shared_utility/platform.h"
  #include "serializer.h"
  #include "iothub_client_ll.h"
  #include "iothubtransporthttp.h"
#endif
#include "sdk/schemaserializer.h"

#include "../examples/iotQi-devices-arduino/settings.h"  // ***Must be independent of example files***
#include "iotQi-globals.h"
#include "iotQi-model.h"

/* ------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------ */

BEGIN_NAMESPACE(IotqiNamespace);

  DECLARE_STRUCT(NetworkInformation,
    ascii_char_ptr, NetworkType,
    ascii_char_ptr, SSID,
    ascii_char_ptr, AuthType,
    ascii_char_ptr, IPAddress
  );
  
  DECLARE_STRUCT(DeviceInformation,
    ascii_char_ptr, DeviceId,
    ascii_char_ptr, VersionInfo
  );  

  DECLARE_STRUCT(CommandInformation,
    ascii_char_ptr_no_quotes, iotqiCommands,
    ascii_char_ptr_no_quotes, userCommands
  );

  
  DECLARE_MODEL(IotqiModel,
    WITH_DATA(ascii_char_ptr, DeviceId),
    WITH_DATA(ascii_char_ptr, VersionInfo),
    WITH_DATA(DeviceInformation, DeviceInfo),
    WITH_DATA(NetworkInformation, NetworkInfo),
    WITH_DATA(CommandInformation, CommandInfo),
    WITH_DATA(ascii_char_ptr_no_quotes, DeviceMeta),
  
    WITH_ACTION(getcommandinfo),
    WITH_ACTION(getversioninfo),
    WITH_ACTION(getdeviceid),
    WITH_ACTION(getnetworkinfo)
  );

END_NAMESPACE(IotqiNamespace);

EXECUTE_COMMAND_RESULT getcommandinfo(IotqiModel* iotqiContext);
EXECUTE_COMMAND_RESULT getversioninfo(IotqiModel* iotqiContext);
EXECUTE_COMMAND_RESULT getdeviceid(IotqiModel* iotqiContext);
EXECUTE_COMMAND_RESULT getnetworkinfo(IotqiModel* iotqiContext);


IotqiModel* iotqiContext;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


EXECUTE_COMMAND_RESULT getdeviceid(IotqiModel* iotqiContext)
{
  (void)iotqiContext;
  (void)printf("Reponding to DeviceId request...\r\n");
  
  unsigned char* buffer;
  size_t bufferSize;

  iotqiContext->DeviceId = (char*)deviceId;
  if (SERIALIZE(&buffer, &bufferSize, iotqiContext->DeviceId) != CODEFIRST_OK)
  {
    (void)printf("Error serializing DeviceId structure.");
    return EXECUTE_COMMAND_ERROR;
  }
  else
  {
    SendMessage(buffer, bufferSize, IotqiMsgType_CommandResponse, IotqiEventClass_Iotqi, "GetDeviceId", "200", lastCmdMessageId);
  }
  return EXECUTE_COMMAND_SUCCESS;
}


EXECUTE_COMMAND_RESULT getversioninfo(IotqiModel* iotqiContext)
{
  (void)iotqiContext;
  (void)printf("Reponding to VersionInfo request...\r\n");
  
  unsigned char* buffer;
  size_t bufferSize;

  iotqiContext->DeviceId = (char*)deviceId;
  iotqiContext->VersionInfo = (char*)versionInfo;
  if (SERIALIZE(&buffer, &bufferSize, iotqiContext->DeviceId, iotqiContext->VersionInfo) != CODEFIRST_OK)
  {
    (void)printf("Error serializing VersionInfo structure.");
    return EXECUTE_COMMAND_ERROR;
  }
  else
  {
    SendMessage(buffer, bufferSize, IotqiMsgType_CommandResponse, IotqiEventClass_Iotqi, "GetVersionInfo", "200", lastCmdMessageId);
  }
  return EXECUTE_COMMAND_SUCCESS;
}


EXECUTE_COMMAND_RESULT getnetworkinfo(IotqiModel* iotqiContext)
{
  (void)iotqiContext;
  (void)printf("Reponding to NetworkInfo request...\r\n");
  
  unsigned char* buffer;
  size_t bufferSize;

  iotqiContext->NetworkInfo.NetworkType = networkType;
  iotqiContext->NetworkInfo.SSID = WIFI_SSID;
  iotqiContext->NetworkInfo.AuthType = authType;
  iotqiContext->NetworkInfo.IPAddress = ipAddress;

  if (SERIALIZE(&buffer, &bufferSize, iotqiContext->DeviceId, iotqiContext->NetworkInfo) != CODEFIRST_OK)
  {
    (void)printf("Error serializing DeviceId structure.");
    return EXECUTE_COMMAND_ERROR;
  }
  else
  {
    SendMessage(buffer, bufferSize, IotqiMsgType_CommandResponse, IotqiEventClass_Iotqi, "GetNetworkInfo", "200", lastCmdMessageId);
  }
  return EXECUTE_COMMAND_SUCCESS;
}


EXECUTE_COMMAND_RESULT getcommandinfo(IotqiModel* iotqiContext)
{
  (void)iotqiContext;
  (void)printf("Reponding to GetCommands request...\r\n");

  STRING_HANDLE iotqiCommandsMeta;
  STRING_HANDLE userCommandsMeta;
  iotqiCommandsMeta = STRING_new();
  userCommandsMeta = STRING_new();

  if (iotqiCommandsMeta == NULL || userCommandsMeta == NULL)
  {
    (void)printf("Failed on creating strings for commands metadata\r\n");
  }
  else
  {
    if (Iotqi_GetCommands(iotqiCommandsMeta) != IOTOS_OK || User_GetCommands(userCommandsMeta) != IOTOS_OK)
    {
      (void)printf("Failed serializing command metadata\r\n");
    }
    else
    {
      unsigned char* buffer;
      size_t bufferSize;
      iotqiContext->DeviceId = (char*)deviceId;
      iotqiContext->CommandInfo.iotqiCommands = (char*)STRING_c_str(iotqiCommandsMeta);
      iotqiContext->CommandInfo.userCommands = (char*)STRING_c_str(userCommandsMeta);

      /* Here is the actual serialization of the device message */
      if (SERIALIZE(&buffer, &bufferSize, iotqiContext->DeviceId, iotqiContext->CommandInfo) != CODEFIRST_OK)
      {
        (void)printf("Failed serializing command response\r\n");
      }
      else
      {
//        char* cmdNameFixup = strstr(buffer, "getCommands");
//        memcpy(cmdNameFixup, "GetCommands", 11);
        (void)printf("Sending GetCommand response %.100s to messageId=%.40s\r\n", buffer, lastCmdMessageId);
        SendMessage(buffer, bufferSize, IotqiMsgType_CommandResponse, IotqiEventClass_Iotqi, "GetCommandInfo", "200", lastCmdMessageId);
      }
    }
    STRING_delete(iotqiCommandsMeta);
    STRING_delete(userCommandsMeta);
  }
  return EXECUTE_COMMAND_SUCCESS;
}


IOTOS_RESULT getDeviceMeta(unsigned char** buffer, size_t* bufferSize)
{
  STRING_HANDLE iotqiCommandsMeta;
  STRING_HANDLE userCommandsMeta;
  iotqiCommandsMeta = STRING_new();
  userCommandsMeta = STRING_new();

  if (iotqiCommandsMeta == NULL || userCommandsMeta == NULL)
  {
    (void)printf("Failed on creating strings for commands metadata\r\n");
  }
  else
  {
    if (Iotqi_GetCommands(iotqiCommandsMeta) != IOTOS_OK || User_GetCommands(userCommandsMeta) != IOTOS_OK)
    {
      (void)printf("Failed serializing command metadata\r\n");
    }
    else
    {
      iotqiContext->DeviceId = (char*)deviceId;
      iotqiContext->DeviceInfo.DeviceId = (char*)deviceId;
      iotqiContext->DeviceInfo.VersionInfo = (char*)versionInfo;

      iotqiContext->CommandInfo.iotqiCommands = (char*)STRING_c_str(iotqiCommandsMeta);
      iotqiContext->CommandInfo.userCommands = (char*)STRING_c_str(userCommandsMeta);

      iotqiContext->NetworkInfo.NetworkType = networkType;
      iotqiContext->NetworkInfo.SSID = WIFI_SSID;
      iotqiContext->NetworkInfo.AuthType = authType;
      iotqiContext->NetworkInfo.IPAddress = ipAddress;


      unsigned char* metaBuffer;
      size_t metaBufferSize;
      if (SERIALIZE(&metaBuffer, &metaBufferSize, iotqiContext->DeviceInfo, iotqiContext->NetworkInfo, iotqiContext->CommandInfo) != CODEFIRST_OK)
      {
        (void)printf("Error serializing device metadata structure.\r\n");
      }
      else
      {
        size_t newSize = metaBufferSize + strlen(deviceId) + 29;      // template-> {"DeviceId":".id.","DeviceMeta": .meta. }
        
        *bufferSize = newSize;
        *buffer = calloc(*bufferSize, sizeof(char));
        
        strncpy(*buffer, "{\"DeviceId\":\"", 13);
        size_t offset = 13;
        strncpy(*buffer + offset, (char*)deviceId, strlen(deviceId));
        offset += strlen(deviceId);
      
        strncpy(*buffer + offset, "\",\"DeviceMeta\":", 15);
        offset += 15;
        strncpy(*buffer + offset, metaBuffer, metaBufferSize);
        offset += metaBufferSize;
        (*buffer)[offset] = '}';
      }      
      STRING_delete(iotqiCommandsMeta);
      STRING_delete(userCommandsMeta);
      free(metaBuffer);
    }
  }
  return IOTOS_OK;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


IOTOS_RESULT Iotqi_ModelInit()
{
  iotqiContext = CREATE_MODEL_INSTANCE(IotqiNamespace, IotqiModel);
  if (iotqiContext == NULL)
  {
    (void)printf("Failed on to create iotQi device model.\r\n");
    return IOTOS_ERROR;
  }
  return IOTOS_OK;
}

void Iotqi_ModelDeinit()
{
  DESTROY_MODEL_INSTANCE(iotqiContext);
}


IOTOS_RESULT Iotqi_GetCommands(STRING_HANDLE commandsMeta)
{
  if (SchemaSerializer_SerializeCommandMetadata(GET_MODEL_HANDLE(IotqiNamespace, IotqiModel), commandsMeta) != SCHEMA_SERIALIZER_OK)
  {
    return IOTOS_ERROR;
  }
  return IOTOS_OK;
}


EXECUTE_COMMAND_RESULT Iotqi_InvokeCommand(char* cmdBuffer)
{
  EXECUTE_COMMAND(iotqiContext, cmdBuffer);
}


