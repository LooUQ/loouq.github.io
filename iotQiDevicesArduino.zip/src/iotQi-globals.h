// Copyright (c) 2016 LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

// Globals.h

#ifndef _IOTQI_GLOBALS_H_
#define _IOTQI_GLOBALS_H_

#include "Arduino.h"
#include "iotQi.h"

#define EVENTNAME_SIZE 81
#define DISPLAYVALUE_SIZE 81

extern IOTHUB_CLIENT_LL_HANDLE iotHubClientHandle;


extern char deviceId[];
extern const char* versionInfo;

extern char networkType[];
extern const char* ssid;
extern char authType[];
extern char ipAddress[];
extern int networkRecovery;

extern const char* lastCmdMessageId;
extern IOTHUB_MESSAGE_HANDLE lastRecvdMsgHandle;

#endif  /*_IOTQI_GLOBALS_H_ */


