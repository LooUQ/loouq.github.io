// Copyright (c) 2016 LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __IOTQIUTILITY_H
#define __IOTQIUTILITY_H


#ifdef __cplusplus
extern "C" {
#endif

  // jsonAddName encapsulates existing json object\array inside a new structure with a name applied to the existing object\array
  void jsonAddName(unsigned char** buffer, size_t* bufferSize, const char* nameToAdd);
  
  // jsonInsert inserts a json object >> "string":value, << into an existing json structure, the inserted obj will be the 1st object
  void jsonInsert(unsigned char** buffer, size_t* bufferSize, const char* objToInsert);
  
  void IPAddressAsString(const char* buffer, uint32_t ipAddr);
  char* GetMessageProperty(IOTHUB_MESSAGE_HANDLE message, const char* const propName);
  void SetGlobalDeviceIdFromConnectionString(const char* connectionString);
  
  float GetVbat();

#ifdef __cplusplus
}
#endif

#endif //#define __IOTQIUTILITY_H
