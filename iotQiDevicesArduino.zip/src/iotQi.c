// Copyright (c) Microsoft. All rights reserved.
// Copyright (c) LooUQ Incorporated. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifdef ARDUINO
  #include "AzureIoTHub.h"
#else
  #include "azure_c_shared_utility/threadapi.h"
  #include "azure_c_shared_utility/platform.h"
  #include "serializer.h"
  #include "iothub_client_ll.h"
  #include "iothubtransporthttp.h"
#endif
#include "sdk/schemaserializer.h"

#include "../examples/iotQi-devices-arduino/settings.h"
#include "iotQi.h"
#include "iotQi-globals.h"
#include "iotQi-utility.h"
#include "../examples/iotQi-devices-arduino/user-model.h"  // Must be independent of example files
#include "iotQi-Model.h"

// iotQi-Recovery.h only required for WiFi recovery process for WINC lockups
//#include <iotQi_Recovery.h>



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Message Properties
const char* const IOTOS_VERSION = "v-1.0";
const char* const HTTP_OK = "200";

const char* const IotqiMsgProp_iotQiVersion = "iotqi-version";
const char* const IotqiMsgProp_MessageType = "message-type";
const char* const IotqiMsgProp_EventClass = "event-class";                       // command class, alert class, or telemetry series metric class
const char* const IotqiMsgProp_EventName = "event-name";                         // user-defined name or title for the series
const char* const IotqiMsgProp_DisplayValue = "display-value";

// iotQi Message Types
const char* const IotqiMsgType_Command = "command";
const char* const IotqiMsgType_CommandResponse = "command-response";
const char* const IotqiMsgType_Telemetry = "telemetry";
const char* const IotqiMsgType_Alert = "alert";

// iotQi Message Event Classes
const char* const IotqiEventClass_Iotqi = "iotqi";
const char* const IotqiEventClass_User = "user";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma region iotQi_globals

  IOTHUB_CLIENT_LL_HANDLE iotHubClientHandle;
  const char* versionInfo = "iotqi-v1.0";
  char networkType[21] = "wifi";
  char authType[11] = "wpa";
  char ipAddress[16] = "0.0.0.0";
  char deviceId[41] = "\0";

  const char* lastCmdMessageId;
  IOTHUB_MESSAGE_HANDLE lastRecvdMsgHandle;

#pragma endregion

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


extern void SendMessage(const unsigned char* buffer, size_t bufferSize, const char* messageType, const char* eventClass, const char* eventName, const char* displayValue, const char* commandId)
{
	IOTHUB_MESSAGE_HANDLE messageHandle = IoTHubMessage_CreateFromByteArray(buffer, bufferSize);
	if (messageHandle == NULL)
	{
		(void)printf("SendMessage():Unable to create a new IoTHub Message\r\n");
	}
	else
	{
    (void)printf("SendMessage(): buffer@%p, bufferSize=%d\r\n", buffer, bufferSize);

    int deviceId_size = strlen(deviceId);
    
    char messageId[40];
    sprintf(messageId, "%s-%d", deviceId, millis());
    IoTHubMessage_SetMessageId(messageHandle, messageId);
    if (commandId != NULL)
    {
      IoTHubMessage_SetCorrelationId(messageHandle, commandId);
    }
    
		MAP_HANDLE propMap = IoTHubMessage_Properties(messageHandle);
    Map_AddOrUpdate(propMap, IotqiMsgProp_iotQiVersion, IOTOS_VERSION);
		Map_AddOrUpdate(propMap, IotqiMsgProp_MessageType, messageType);
    Map_AddOrUpdate(propMap, IotqiMsgProp_EventClass, eventClass);
    Map_AddOrUpdate(propMap, IotqiMsgProp_EventName, eventName);
    if (strcmp(messageType, IotqiMsgType_CommandResponse) == 0)
    {
      Map_AddOrUpdate(propMap, IotqiMsgProp_DisplayValue, HTTP_OK);
    }
    else
    {
      Map_AddOrUpdate(propMap, IotqiMsgProp_DisplayValue, displayValue);
    }

    //to turn on\off sendCallback method uncomment the appropriate line below
    //#define SENDCALLBACK sendCallback
    #define SENDCALLBACK NULL

		if (IoTHubClient_LL_SendEventAsync(iotHubClientHandle, messageHandle, SENDCALLBACK, NULL) != IOTHUB_CLIENT_OK)
		{
			(void)printf("Failed to hand over the message to IoTHub client");
		}
		else
		{
			//(void)printf("IoTHub client accepted the message for delivery\r\n");
		}
		IoTHubMessage_Destroy(messageHandle);
	}
	free((void*)buffer);
}


void sendCallback(IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback)
{
  int messageTrackingId = (intptr_t)userContextCallback;
  (void)printf("SendCallback: MessageId=%d Result=%s \r\n", messageTrackingId, ENUM_TO_STRING(IOTHUB_CLIENT_CONFIRMATION_RESULT, result));
}


/*this function "links" IoTHub to the serialization library*/
static IOTHUBMESSAGE_DISPOSITION_RESULT ioTHubMessageCallback(IOTHUB_MESSAGE_HANDLE messageHandle)
{
	IOTHUBMESSAGE_DISPOSITION_RESULT result;
	const unsigned char* buffer;
	size_t bufferSize;
	if (IoTHubMessage_GetByteArray(messageHandle, &buffer, &bufferSize) != IOTHUB_MESSAGE_OK)
	{
		(void)printf("IoTHubMessageCallback(): Unable to convert IoT hub message to local buffer.\r\n");
		result = EXECUTE_COMMAND_ERROR;
	}
	else
	{
    (void)printf("ioTHubMessageCallback(): buffer@%p, bufferSize=%d\r\n", buffer, bufferSize);
    (void)printf("iotHubMessageCallback(): %.100s \r\n", buffer);
    lastCmdMessageId = IoTHubMessage_GetMessageId(messageHandle);
    lastRecvdMsgHandle = messageHandle;

    char* cmdBuffer = (char*)calloc(bufferSize + 1, sizeof(char));        // create null terminated buffer
    memcpy(cmdBuffer, buffer, bufferSize);

    EXECUTE_COMMAND_RESULT executeCommandResult;
    const char* cmdName = GetMessageProperty(messageHandle, IotqiMsgProp_EventName);
    const char* cmdClass = GetMessageProperty(messageHandle, IotqiMsgProp_EventClass);

    (void)printf("iotHubMessageCallback(): cmd: %s\\%s \r\n", cmdClass, cmdName);
    if (strcmp(cmdClass, "iotqi") == 0)
    {
      (void)printf("Processing iotQi Command: %s \r\n", buffer);
      executeCommandResult = Iotqi_InvokeCommand(cmdBuffer);
    }
    else
    {
      (void)printf("Processing User Command: %s \r\n", buffer);
      executeCommandResult = User_InvokeCommand(cmdBuffer);
    }
    // to retry command errors (hub resend) set command error = IOTHUBMESSAGE_ABANDONED, default is not to retry (IOTHUBMESSAGE_REJECTED)
		result = (executeCommandResult == EXECUTE_COMMAND_ERROR) ? IOTHUBMESSAGE_REJECTED : (executeCommandResult == EXECUTE_COMMAND_SUCCESS) ? IOTHUBMESSAGE_ACCEPTED : IOTHUBMESSAGE_REJECTED;
		free((char*)cmdBuffer);
    free((char*)buffer);
	}
	return result;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void iotQi_Run(const char* connectionString, unsigned int telemetryInterval)
{
  SetGlobalDeviceIdFromConnectionString(connectionString);
  char deviceIdJson[120];
  sprintf(deviceIdJson, "\"DeviceId\":\"%s\"", deviceId);
  printf("_Run() deviceId obj: %s \r\n", deviceIdJson);

  if (platform_init() != 0)
  {
      (void)printf("Failed to initialize the platform.\r\n");
  }
  else
  {
  	if (serializer_init(NULL) != SERIALIZER_OK)
  	{
  		(void)printf("Failed on Message Serializer Initialization\r\n");
  	}
  	else
  	{
  		iotHubClientHandle = IoTHubClient_LL_CreateFromConnectionString(connectionString, HTTP_Protocol);
  		if (iotHubClientHandle == NULL)
  		{
  			(void)printf("Failed on IoTHubClient_CreateFromConnectionString\r\n");
  		}
  		else
  		{
        (void)printf("Created IoTHubClient.\r\n");
  
        #ifdef MBED_BUILD_TIMESTAMP
  		    	// For mbed add the certificate information
  			    if (IoTHubClient_LL_SetOption(iotHubClientHandle, "TrustedCerts", certificates) != IOTHUB_CLIENT_OK)
      			{
      				(void)printf("failure to set option \"TrustedCerts\"\r\n");
      			}
        #endif // MBED_BUILD_TIMESTAMP
  
        //because it can poll "after minimum polling interval seconds" polls will happen effectively at ~telemetryInterval seconds
  			unsigned int minimumPollingTime = telemetryInterval - 1;
  			if (IoTHubClient_LL_SetOption(iotHubClientHandle, "MinimumPollingTime", &minimumPollingTime) != IOTHUB_CLIENT_OK)
  			{
  				(void)printf("Failure to set option \"MinimumPollingTime\"\r\n");
  			}
  
        // --------------------------------------------------------------------------------------------------------------------------
        
  
        if (Iotqi_ModelInit() != IOTOS_OK || User_ModelInit() != IOTOS_OK)
  			{
  				(void)printf("Failed on CREATE_MODEL_INSTANCE\r\n");
  			}
  			else
  			{
  				if (IoTHubClient_LL_SetMessageCallback(iotHubClientHandle, ioTHubMessageCallback, NULL) != IOTHUB_CLIENT_OK)
  				{
  					(void)printf("unable to IoTHubClient_SetMessageCallback\r\n");
  				}
  				else
  				{
            /* Here is the actual send of the Device Info */
            unsigned char* buffer;
            size_t bufferSize;
            if (getDeviceMeta(&buffer, &bufferSize) != IOTOS_OK)
            {
              (void)printf("Failed fetching device metadata\r\n");
            }
            else
            {
  						SendMessage(buffer, bufferSize, IotqiMsgType_Alert, IotqiEventClass_Iotqi, "DeviceMeta", deviceId, "");
  
              int currentTelemetryCycle = 0;
              while (1)
              {
                if (currentTelemetryCycle >= telemetryInterval) 
                {
                  currentTelemetryCycle = 0;
                  unsigned char* buffer;
                  size_t bufferSize;
                  char eventName[EVENTNAME_SIZE];
                  char displayValue[DISPLAYVALUE_SIZE];
                  
                  if (GetTelemetrySample(&buffer, &bufferSize, eventName, displayValue) != IOTOS_OK)
                  {
                    (void)printf("Failed getting sensor values (telemetry)\r\n");
                  }
                  else
                  {
                    // condition sample for iotQi cloud
                    jsonAddName(&buffer, &bufferSize, "UserData");
                    jsonInsert(&buffer, &bufferSize, deviceIdJson);

                    (void)printf("_Run() Sending: %s\r\n\r\n", buffer);
                    SendMessage(buffer, bufferSize, IotqiMsgType_Telemetry, IotqiEventClass_User, eventName, displayValue, "");

                  }
                }
                IoTHubClient_LL_DoWork(iotHubClientHandle);
                ThreadAPI_Sleep(1000);
                currentTelemetryCycle++;
              }
  					}
  				}
  			}
        User_ModelDeinit();
        Iotqi_ModelDeinit();
  		}
  			IoTHubClient_LL_Destroy(iotHubClientHandle);
  	}
    serializer_deinit();
  }
  platform_deinit();
}
